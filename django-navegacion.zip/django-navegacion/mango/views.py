from django.shortcuts import render
from mango.models import Manguito

# Create your views here.
def index(request):
    return render(request,'index.html',{})

def manguito(request):
    mangos = Manguito.objects.all()
    context = {
        'mangos':mangos
    }
    return render(request,'manguito.html',context)

def mango_index(request):
    

    return render(request,'mango_index.html' ,context)