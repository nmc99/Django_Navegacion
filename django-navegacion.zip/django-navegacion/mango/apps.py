from django.apps import AppConfig


class MangoConfig(AppConfig):
    name = 'mango'
